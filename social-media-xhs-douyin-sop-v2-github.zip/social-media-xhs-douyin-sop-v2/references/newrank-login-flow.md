# Newrank Login Flow (`xh.newrank.cn`)

## Goal
- Ensure the agent can reach logged-in state before running rank mining.

## Required inputs
- Entry URL (`https://xh.newrank.cn/`)
- Account
- Password
- Permission to run auto collection

## Gate steps (strict)
1. Open `https://xh.newrank.cn/`.
2. If redirected to `newrank.cn/user/login?platform=4`, switch to `其他登录方式` -> `密码登录`.
3. Fill account and password.
4. If slider captcha appears:
   - Prefer headed session (`--headed`) and ask human to pass slider once.
   - Keep same browser session while mining.
5. Verify login success:
   - `xh.newrank.cn` left menu visible (`找笔记/笔记榜单` etc.).
   - Pages `/notes/notesRank/boost`, `/hot`, `/business` are accessible without login redirect.
6. If login still fails:
   - Mark as `offline evidence mode`.
   - Request manual export/screenshot for three rankings.

## Session persistence guidance
- Prefer stable named sessions (e.g., `-s=xh3`) during one run.
- If environment allows persistent storage state, save it and reuse for subsequent mining runs.
- Do not assume Safari/Chrome local login state can be shared into automation session.

## Failure handling
- Network/package issue: report blocker and fallback to offline evidence mode.
- Captcha blocked: request one-time human pass in headed browser.
- Session reset: re-check login gate before continuing mining.
