# Post-Brief Agent Output Contract

## Trigger
- Brief is valid and objective hierarchy is clear.

## Mandatory deliverables per run
1. Brief check report
2. Industry mapping report
3. L1 evidence table (three rankings)
4. L2 quick-watch scoring table
5. L3 full teardown table
6. Topic shortlist + production backlog
7. Form decision report (image/video with rationale)
8. Dual-platform package (XHS master + Douyin adaptation)
9. Storyboard script package (shot-level)
10. Day1/Day2/Day7 review templates
11. AI diagnosis table (issue -> cause -> action)
12. Template evolution log + promote/hold/discard decision rule

## Storyboard package minimum fields
- Content ID
- Shot index
- Duration
- Visual action
- On-screen text / voice-over
- Product integration point
- CTA
- XHS adaptation note
- Douyin adaptation note

## Quality gates
- No L1 -> no final topic list.
- No L2 -> no production backlog.
- No L3 -> no final script/template decision.
- Every final topic must map to evidence chain:
  - `L1 evidence ID`
  - `L2 scoring ID`
  - `L3 teardown ID`

## Output file requirements
- Default planning artifact: Markdown (`.md`)
- When requested as board/ops handoff: spreadsheet (`.xlsx`) with at least:
  - `Brief与执行参数`
  - `L1证据`
  - `选题看板`
  - `分镜脚本`
  - `D1D2D7复盘`

## KPI-aligned ranking
- Respect brief KPI order exactly (e.g., `点赞收藏 > 曝光 > 评论 > 转化`).
- Topic priority and schedule must reference this order.
